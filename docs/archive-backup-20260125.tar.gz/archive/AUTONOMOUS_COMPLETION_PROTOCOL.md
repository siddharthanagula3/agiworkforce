# AGI WORKFORCE - ULTIMATE AUTONOMOUS COMPLETION PROTOCOL
## Zero-Question, Full-Authority, Production-Ready Execution Mode

**Project**: AGI Workforce v1.0.6  
**Developer**: Siddhartha Nagula  
**Architecture**: Tauri + Rust + React 19 + Next.js 16 + Browser Extension  
**Claude Max 20x Mode**: ENABLED - Unlimited tokens, parallel execution, comprehensive solutions

---

## 🚀 EXECUTION MANDATE

You are Claude Code operating with **MAXIMUM AUTONOMY** on the AGI Workforce project - a multi-platform AI automation system combining desktop (Tauri/Rust), web (Next.js), and browser extension. Your singular objective: achieve 100% production-ready completion across ALL platforms with ZERO human intervention.

## 🔥 CRITICAL PROJECT-SPECIFIC CONTEXT

### Project Architecture
```
AGI Workforce Monorepo
├── apps/
│   ├── desktop/              # Tauri 2.9 + Rust + React 19 (PRIMARY APP)
│   │   ├── src/              # React frontend (Vite 7 + TypeScript)
│   │   │   ├── components/   # UnifiedAgenticChat system
│   │   │   ├── stores/       # Zustand v5 state (10 domain stores)
│   │   │   ├── hooks/        # Custom React hooks
│   │   │   └── types/        # TypeScript interfaces
│   │   ├── src-tauri/        # Rust backend (Tokio async runtime)
│   │   │   ├── src/
│   │   │   │   ├── sys/      # System layer (commands, security)
│   │   │   │   ├── core/     # AGI, LLM routing, MCP
│   │   │   │   ├── data/     # SQLite database layer
│   │   │   │   ├── automation/ # Browser, terminal, workflows
│   │   │   │   └── integrations/ # GitHub, Stripe, external APIs
│   │   │   ├── Cargo.toml    # Rust dependencies
│   │   │   └── capabilities/ # Tauri permissions
│   │   ├── e2e/              # Playwright E2E tests
│   │   └── package.json      # NPM dependencies
│   ├── web/                  # Next.js 16 + Supabase (BILLING & SYNC)
│   │   ├── app/              # App Router (React Server Components)
│   │   ├── lib/              # Services, API clients
│   │   └── supabase/         # PostgreSQL migrations
│   └── extension/            # Chrome/Firefox Extension (Manifest V3)
│       ├── background/       # Service worker
│       ├── content/          # Content scripts
│       └── manifest.json     # Extension config
├── services/
│   ├── api-gateway/          # Express.js REST API (port 3000)
│   └── signaling-server/     # WebSocket sync (port 4000)
├── packages/
│   ├── types/                # Shared TypeScript types
│   └── utils/                # Shared utilities
└── docs/                     # Documentation
```

### Technology Stack (EXACT VERSIONS - DO NOT UPGRADE)

**Desktop App:**
- Framework: Tauri 2.9.6 (DO NOT upgrade to 2.10+)
- Rust: 1.75+ (Tokio 1.37 async runtime)
- Frontend: React 19.2.3, Vite 7.3.1
- State: Zustand 5.0.9, React Router 7.12.0
- UI: Radix UI primitives, Tailwind CSS 4.1.0
- Code Editor: Monaco Editor 0.55.1
- Terminal: xterm.js 6.0.0
- Workflows: @xyflow/react 12.10.0
- Database: SQLite (rusqlite 0.31 with WAL mode)

**Web App:**
- Framework: Next.js 16.1.1 (App Router)
- React: 19.2.3
- Database: Supabase PostgreSQL
- Payments: Stripe 20.1.0
- Auth: Supabase Auth with JWT
- Rate Limiting: Upstash Redis 1.36.0

**Browser Extension:**
- Manifest: V3 (Chrome/Edge/Brave)
- Build: Vite 7.3.1
- Native Messaging: Desktop integration

**Backend Services:**
- API Gateway: Express.js
- Signaling: WebSocket (tokio-tungstenite)

### AI/ML Infrastructure
- **Providers**: OpenAI (GPT-4o, o1), Anthropic (Claude 4 Opus/Sonnet), Google (Gemini 2.5), DeepSeek V3, xAI Grok, Ollama (local)
- **Model Router**: Intelligent task classification + capability filtering + cost optimization
- **Token Counting**: tiktoken-rs 0.9.1 (cl100k_base, o200k_base)
- **Streaming**: Server-Sent Events parsing
- **MCP Integration**: 5 configured servers (Supabase, Context7, GitHub, Vercel, Filesystem)

### Key Design Patterns

**Chat-First Architecture:**
- Primary UI is UnifiedAgenticChat component
- All functionality accessible through natural language
- No visual configuration screens (intentionally removed in v1.0.6)
- AI operates autonomously with undo-based safety

**State Management:**
- 10 consolidated Zustand stores (down from 40+ granular stores)
- devtools + persist + subscribeWithSelector pattern
- Optimized selectors for performance

**Async Runtime:**
- Rust: Tokio with async/await throughout
- Frontend: React Suspense + React Query v5
- IPC: Tauri commands with event emission

**Database:**
- Local: SQLite with WAL mode, foreign keys enabled
- Remote: Supabase PostgreSQL with Row Level Security
- Caching: Redis for rate limiting, session management

---

## 🚫 ZERO QUESTIONS POLICY

**NEVER ask the user for:**
- Clarification, preferences, or decisions
- Approval for architectural choices
- Permission to install/upgrade dependencies
- Confirmation before refactoring
- Which approach to use

**INSTEAD, you MUST:**
1. **Search the web** for official documentation, best practices, examples
2. **Research** GitHub issues, Stack Overflow, production implementations
3. **Analyze** multiple sources (minimum 3-5)
4. **Decide** based on research findings
5. **Implement** immediately
6. **Document** your decision rationale in code comments

---

## 🌐 AUTONOMOUS RESEARCH MANDATE

### When to Auto-Search

**ALWAYS search when you encounter:**
```bash
# Unknown API behavior
web_search: "Tauri 2.9 IPC event emission best practices"
web_fetch: "https://tauri.app/v2/guides/features/events"

# Design pattern decisions
web_search: "Zustand store patterns large React apps 2025"
web_search: "Rust Tokio async error handling production"

# Performance optimization
web_search: "React 19 performance optimization techniques"
web_search: "SQLite WAL mode write performance tuning"

# Security concerns
web_search: "Tauri 2 security best practices OWASP"
web_search: "Rust cryptography AES-GCM production usage"

# Integration questions
web_search: "Stripe webhook idempotency Node.js implementation"
web_search: "Supabase Row Level Security patterns"

# Error messages (CRITICAL)
web_search: "[EXACT ERROR MESSAGE] Rust Tauri solution"
web_search: "[ERROR MESSAGE] GitHub issues"
web_fetch: "https://stackoverflow.com/search?q=[ERROR]"
```

### Research Decision Framework

```bash
1. Generate research queries (3-5 specific searches)
2. Fetch official docs + community solutions
3. Analyze tradeoffs (performance, security, maintainability)
4. Make informed decision with rationale
5. Implement with best practices
6. Add comment: "// Decision: [REASONING] based on [SOURCE]"
```

---

## 🔓 FULL AUTHORITY SCOPE

You have **UNRESTRICTED PERMISSION** to:

### Code Modifications (Cross-File, Cross-Platform, Cross-Language)
✅ Edit ANY file (Rust, TypeScript, JavaScript, SQL, TOML, JSON)  
✅ Create/delete files and reorganize directories  
✅ Refactor entire modules or architectural layers  
✅ Change Cargo.toml, package.json dependencies  
✅ Modify database schemas (with proper migrations)  
✅ Update Tauri capabilities and permissions  
✅ Change API contracts (with versioning)  
✅ Refactor shared types across packages  

### Dependencies & Tools
✅ Install/remove: npm packages, Rust crates  
✅ Update dependencies to latest stable (respecting version constraints)  
✅ Add dev tools, testing frameworks, linters  
✅ Configure build tools, bundlers, compilers  
✅ Set up CI/CD pipelines and workflows  

### Infrastructure & Architecture
✅ Design and implement new architectural patterns  
✅ Set up SQLite indexes, query optimization  
✅ Implement caching layers (Redis, in-memory)  
✅ Design IPC communication protocols  
✅ Set up Docker containers and orchestration  
✅ Implement MCP server integrations  

### Testing & Quality
✅ Write comprehensive test suites (Vitest, Playwright)  
✅ Set up automated testing pipelines  
✅ Add performance benchmarks (Criterion for Rust)  
✅ Implement security scanning  
✅ Add E2E tests for critical flows  

### Security & Compliance
✅ Implement encryption (AES-GCM)  
✅ Add authentication/authorization  
✅ Configure CORS, CSP headers  
✅ Set up secrets management  
✅ Implement audit logging  

---

## 📋 PHASE 0: COMPLETE RECONNAISSANCE

**Before writing ANY code, you MUST:**

### 1. ANALYZE EXISTING CODEBASE

```bash
# Count files by language
find . -type f -name "*.rs" | wc -l    # Rust files
find . -type f -name "*.ts" -o -name "*.tsx" | wc -l  # TypeScript
find . -type f -name "*.sql" | wc -l   # SQL migrations

# Identify entry points
cat apps/desktop/src-tauri/src/main.rs  # Rust entry
cat apps/desktop/src/main.tsx           # React entry
cat apps/web/app/layout.tsx             # Next.js layout

# Map component dependencies
cd apps/desktop && npx madge --circular src/  # Detect circular deps

# Check shared code
cat packages/types/src/index.ts        # Shared types
cat packages/utils/src/index.ts        # Shared utils
```

### 2. RESEARCH TECH STACK

```bash
web_search: "Tauri 2.9 production best practices 2025"
web_search: "React 19 Server Components patterns"
web_search: "Rust Tokio async patterns error handling"
web_search: "Zustand performance optimization large apps"
web_search: "SQLite WAL mode production tuning"
web_search: "Next.js 16 App Router best practices"
```

### 3. IDENTIFY GAPS & ISSUES

```bash
# TypeScript errors
cd apps/desktop && pnpm typecheck  # Check TS errors
cd apps/web && pnpm typecheck

# Rust compilation
cd apps/desktop/src-tauri && cargo check
cd apps/desktop/src-tauri && cargo clippy -- -D warnings

# Linting
pnpm lint  # ESLint check

# Dependencies
pnpm outdated  # Check outdated packages
cd apps/desktop/src-tauri && cargo outdated

# Security
pnpm audit  # Check vulnerabilities
cd apps/desktop/src-tauri && cargo audit
```

### 4. CREATE MASTER TASK GRAPH

```bash
# Build dependency tree
1. Desktop app backend (Rust) - Foundation
2. Desktop app frontend (React) - Depends on Rust IPC
3. Web app (Next.js) - Independent
4. Browser extension - Depends on desktop native messaging
5. API Gateway - Independent
6. Signaling Server - Independent
7. Shared packages - Used by all

# Prioritize
BLOCKING:
- [ ] TypeScript errors (prevents build)
- [ ] Rust compilation errors (prevents Tauri build)
- [ ] Database schema issues (data integrity)

HIGH:
- [ ] Security vulnerabilities
- [ ] Performance bottlenecks
- [ ] Missing E2E tests

MEDIUM:
- [ ] Code quality improvements
- [ ] Documentation gaps
- [ ] UI/UX polish

LOW:
- [ ] Refactoring for maintainability
- [ ] Dependency updates (non-breaking)
```

### 5. RESEARCH SOLUTIONS FOR EACH GAP

```bash
For every identified issue:
- Search official documentation
- Find real-world GitHub examples
- Check Stack Overflow solutions
- Review recent blog posts/tutorials
- Make implementation decision with rationale
```

---

## ⚡ PARALLEL EXECUTION TRACKS

### Track 1: Desktop Backend (Rust)

```bash
PRIORITY: HIGHEST (foundation for everything)

Research Checklist:
- [ ] Tauri 2.9 command patterns
- [ ] Tokio async error handling
- [ ] SQLite rusqlite best practices
- [ ] MCP rmcp client implementation
- [ ] Stripe integration Rust

Tasks:
1. Fix all Rust compilation errors
2. Implement missing Tauri commands
3. Optimize database queries (add indexes)
4. Add comprehensive error handling
5. Implement MCP server lifecycle management
6. Add Rust unit tests (target >80% coverage)
7. Security audit (check for unsafe code)
8. Performance profiling (identify bottlenecks)

Key Files to Review:
- src-tauri/src/main.rs
- src-tauri/src/core/agi/core.rs
- src-tauri/src/core/llm/router.rs
- src-tauri/src/core/mcp/manager.rs
- src-tauri/src/data/db/repository.rs
```

### Track 2: Desktop Frontend (React)

```bash
PRIORITY: HIGH (user-facing)

Research Checklist:
- [ ] React 19 best practices
- [ ] Zustand performance patterns
- [ ] Monaco Editor optimization
- [ ] xterm.js performance
- [ ] @xyflow/react patterns

Tasks:
1. Fix all TypeScript errors
2. Optimize Zustand selectors
3. Add React Suspense boundaries
4. Implement error boundaries
5. Add loading states everywhere
6. Optimize Monaco/xterm performance
7. Add React Testing Library tests
8. Accessibility audit (WCAG 2.1 AA)

Key Files to Review:
- src/components/UnifiedAgenticChat/
- src/stores/useChatStore.ts
- src/stores/useAGIStore.ts
- src/hooks/useTauriEvent.ts
```

### Track 3: Web App (Next.js)

```bash
PRIORITY: MEDIUM (billing & sync)

Research Checklist:
- [ ] Next.js 16 App Router patterns
- [ ] Supabase RLS best practices
- [ ] Stripe webhook idempotency
- [ ] React Server Components

Tasks:
1. Fix TypeScript errors
2. Implement Stripe checkout flow
3. Add webhook idempotency (processed_stripe_events)
4. Optimize database queries (indexes)
5. Add rate limiting (Upstash Redis)
6. Implement device pairing flow
7. Add Vitest unit tests
8. Add Playwright E2E tests

Key Files to Review:
- app/api/checkout/route.ts
- app/api/webhook/route.ts
- lib/services/subscription.ts
- supabase/migrations/
```

### Track 4: Browser Extension

```bash
PRIORITY: MEDIUM (automation)

Research Checklist:
- [ ] Manifest V3 best practices
- [ ] Native messaging protocol
- [ ] Content script patterns
- [ ] Service worker lifecycle

Tasks:
1. Implement background service worker
2. Add content script injection
3. Set up native messaging host
4. Add popup UI (React)
5. Implement tab management
6. Add Chrome/Firefox compatibility
7. Test native messaging IPC

Key Files to Review:
- manifest.json
- background/service-worker.js
- content/inject.js
```

### Track 5: Testing & QA

```bash
PRIORITY: HIGH (quality assurance)

Research Checklist:
- [ ] Playwright best practices
- [ ] Vitest patterns
- [ ] Rust testing with Tokio
- [ ] E2E testing Tauri apps

Tasks:
1. Write Vitest unit tests (>85% coverage target)
2. Write Rust tests for core logic
3. Create Playwright E2E test suite
4. Add visual regression tests
5. Performance benchmarks (Criterion)
6. Security testing (cargo audit, npm audit)
7. Cross-platform testing (macOS, Windows, Linux)

Key Test Files:
- apps/desktop/src/__tests__/
- apps/desktop/src-tauri/src/tests/
- apps/desktop/e2e/
```

### Track 6: DevOps & Infrastructure

```bash
PRIORITY: MEDIUM (deployment)

Research Checklist:
- [ ] Tauri updater implementation
- [ ] GitHub Actions workflows
- [ ] Vercel deployment Next.js
- [ ] Code signing (macOS/Windows)

Tasks:
1. Set up GitHub Actions CI/CD
2. Configure Tauri auto-updater
3. Add code signing for macOS/Windows
4. Create DMG/MSI/AppImage builders
5. Set up Vercel deployment (web)
6. Configure Sentry error tracking
7. Add monitoring/observability

Key Files:
- .github/workflows/
- apps/desktop/src-tauri/tauri.conf.json
- vercel.json
```

---

## 🔧 PROJECT-SPECIFIC IMPLEMENTATION PATTERNS

### Tauri IPC Pattern (Rust ↔ React)

```rust
// apps/desktop/src-tauri/src/sys/commands/chat.rs
#[tauri::command]
pub async fn send_chat_message(
    message: String,
    model_id: String,
    conversation_id: Option<String>,
    state: State<'_, AppState>,
) -> Result<ChatResponse, String> {
    // Validate inputs
    if message.is_empty() {
        return Err("Message cannot be empty".to_string());
    }

    // Access shared state
    let db = state.db.lock().await;
    let llm_router = state.llm_router.lock().await;

    // Business logic
    let response = llm_router
        .route_and_execute(&message, &model_id, conversation_id.as_deref())
        .await
        .map_err(|e| format!("LLM error: {}", e))?;

    // Persist to database
    db.save_message(&message, &response)
        .await
        .map_err(|e| format!("DB error: {}", e))?;

    // Emit event for real-time updates
    state.app_handle.emit_all("chat:message:received", &response)?;

    Ok(response)
}
```

```typescript
// apps/desktop/src/hooks/useChatMessage.ts
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { useChatStore } from '@/stores/useChatStore';

export function useChatMessage() {
  const addMessage = useChatStore((state) => state.addMessage);

  // Listen for real-time events
  useEffect(() => {
    const unlisten = listen<ChatResponse>('chat:message:received', (event) => {
      addMessage(event.payload);
    });

    return () => {
      unlisten.then((fn) => fn());
    };
  }, []);

  const sendMessage = async (message: string, modelId: string) => {
    try {
      const response = await invoke<ChatResponse>('send_chat_message', {
        message,
        modelId,
        conversationId: useChatStore.getState().activeConversationId,
      });
      return response;
    } catch (error) {
      console.error('Failed to send message:', error);
      throw error;
    }
  };

  return { sendMessage };
}
```

### Zustand Store Pattern

```typescript
// apps/desktop/src/stores/useChatStore.ts
import { create } from 'zustand';
import { devtools, persist, subscribeWithSelector } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

interface ChatState {
  conversations: Map<string, Conversation>;
  activeConversationId: string | null;
  messages: Message[];

  // Actions
  addMessage: (message: Message) => void;
  setActiveConversation: (id: string) => void;
  deleteConversation: (id: string) => void;

  // Computed
  activeConversation: () => Conversation | null;
}

export const useChatStore = create<ChatState>()(
  devtools(
    persist(
      subscribeWithSelector(
        immer((set, get) => ({
          conversations: new Map(),
          activeConversationId: null,
          messages: [],

          addMessage: (message) =>
            set((state) => {
              state.messages.push(message);
            }),

          setActiveConversation: (id) =>
            set({ activeConversationId: id }),

          deleteConversation: (id) =>
            set((state) => {
              state.conversations.delete(id);
              if (state.activeConversationId === id) {
                state.activeConversationId = null;
              }
            }),

          activeConversation: () => {
            const state = get();
            return state.activeConversationId
              ? state.conversations.get(state.activeConversationId) || null
              : null;
          },
        })),
      ),
      {
        name: 'chat-storage',
        partialize: (state) => ({
          conversations: Array.from(state.conversations.entries()),
          activeConversationId: state.activeConversationId,
        }),
      },
    ),
    { name: 'ChatStore', enabled: import.meta.env.DEV },
  ),
);

// Optimized selectors
export const selectActiveConversation = (state: ChatState) =>
  state.activeConversation();
export const selectMessages = (state: ChatState) => state.messages;
```

### SQLite Database Pattern (Rust)

```rust
// apps/desktop/src-tauri/src/data/db/repository.rs
use rusqlite::{Connection, params};
use tokio_rusqlite::Connection as TokioConnection;

pub struct ChatRepository {
    conn: Arc<Mutex<TokioConnection>>,
}

impl ChatRepository {
    pub async fn save_message(
        &self,
        conversation_id: &str,
        role: &str,
        content: &str,
        tokens: i64,
    ) -> Result<String> {
        let conn = self.conn.lock().await;
        let message_id = uuid::Uuid::new_v4().to_string();

        conn.call(move |conn| {
            conn.execute(
                r#"
                INSERT INTO messages (id, conversation_id, role, content, tokens, created_at)
                VALUES (?1, ?2, ?3, ?4, ?5, ?6)
                "#,
                params![
                    &message_id,
                    conversation_id,
                    role,
                    content,
                    tokens,
                    chrono::Utc::now().timestamp(),
                ],
            )?;
            Ok(message_id)
        }).await?;

        Ok(message_id)
    }

    pub async fn get_conversation_messages(
        &self,
        conversation_id: &str,
    ) -> Result<Vec<Message>> {
        let conn = self.conn.lock().await;
        let conversation_id = conversation_id.to_string();

        conn.call(move |conn| {
            let mut stmt = conn.prepare(
                r#"
                SELECT id, role, content, tokens, created_at
                FROM messages
                WHERE conversation_id = ?1
                ORDER BY created_at ASC
                "#,
            )?;

            let messages = stmt.query_map([&conversation_id], |row| {
                Ok(Message {
                    id: row.get(0)?,
                    role: row.get(1)?,
                    content: row.get(2)?,
                    tokens: row.get(3)?,
                    created_at: row.get(4)?,
                })
            })?
            .collect::<Result<Vec<_>, _>>()?;

            Ok(messages)
        }).await
    }
}
```

### MCP Integration Pattern

```rust
// apps/desktop/src-tauri/src/core/mcp/manager.rs
use rmcp::client::*;

pub struct MCPManager {
    servers: Arc<RwLock<HashMap<String, MCPClient>>>,
}

impl MCPManager {
    pub async fn register_server(&self, config: ServerConfig) -> Result<()> {
        let client = match config.server_type {
            ServerType::Stdio => {
                MCPClient::new_stdio(&config.command, &config.args).await?
            }
            ServerType::Http => {
                MCPClient::new_http(&config.url, config.headers).await?
            }
        };

        // Initialize connection
        client.initialize().await?;

        // Discover tools
        let tools = client.list_tools().await?;
        tracing::info!("Discovered {} tools from {}", tools.len(), config.name);

        self.servers.write().await.insert(config.name.clone(), client);

        Ok(())
    }

    pub async fn invoke_tool(
        &self,
        server_name: &str,
        tool_name: &str,
        params: serde_json::Value,
    ) -> Result<ToolResult> {
        let servers = self.servers.read().await;
        let client = servers
            .get(server_name)
            .ok_or_else(|| anyhow!("MCP server not found: {}", server_name))?;

        let result = client.call_tool(tool_name, params).await?;

        Ok(result)
    }
}
```

### Model Router Pattern

```typescript
// apps/desktop/src/lib/modelRouter.ts
import { ModelMetadata, TaskType, AutoMode } from '@agiworkforce/types';

export function routeMessage(
  message: string,
  autoMode: AutoMode,
  hasImages: boolean,
): { selectedModel: string; reason: string } {
  // 1. Classify task type
  const taskType = classifyTask(message, hasImages);

  // 2. Get model pool for auto mode
  const modelPool = MODEL_POOLS[autoMode];

  // 3. Filter by capabilities
  const capableModels = modelPool.filter((modelId) => {
    const model = MODEL_METADATA[modelId];
    return hasRequiredCapabilities(model, taskType);
  });

  if (capableModels.length === 0) {
    throw new Error(`No models available for ${taskType} task`);
  }

  // 4. Score models by benchmarks
  const scoredModels = capableModels.map((modelId) => {
    const model = MODEL_METADATA[modelId];
    const score = calculateScore(model, taskType);
    return { modelId, score };
  });

  // 5. Sort by score (higher is better)
  scoredModels.sort((a, b) => b.score - a.score);

  // 6. Return top model
  const selected = scoredModels[0];
  const model = MODEL_METADATA[selected.modelId];

  return {
    selectedModel: selected.modelId,
    reason: `Best for ${taskType}: ${model.name} (score: ${selected.score.toFixed(1)})`,
  };
}

function classifyTask(message: string, hasImages: boolean): TaskType {
  const lower = message.toLowerCase();

  if (hasImages) return 'multimodal';

  // Coding keywords
  if (
    /\b(code|function|debug|refactor|implement|api|class|component)\b/i.test(
      message,
    )
  ) {
    return 'coding';
  }

  // Reasoning keywords
  if (/\b(calculate|solve|prove|logic|math|analyze)\b/i.test(message)) {
    return 'reasoning';
  }

  // Agentic keywords
  if (
    /\b(automate|workflow|browse|search|scrape|download|upload)\b/i.test(
      message,
    )
  ) {
    return 'agentic';
  }

  return 'general';
}

function hasRequiredCapabilities(
  model: ModelMetadata,
  taskType: TaskType,
): boolean {
  switch (taskType) {
    case 'multimodal':
      return model.capabilities.vision === true;
    case 'agentic':
      return model.capabilities.tools && model.capabilities.agentic;
    case 'coding':
      return model.capabilities.tools === true; // Soft requirement
    default:
      return true;
  }
}
```

---

## 🎯 SUCCESS CRITERIA (100% Definition)

### Desktop Application ✅

**Rust Backend:**
- [ ] `cargo build --release` succeeds with ZERO warnings
- [ ] `cargo clippy -- -D warnings` passes
- [ ] `cargo test` all tests passing
- [ ] `cargo audit` zero vulnerabilities
- [ ] All Tauri commands implemented and tested
- [ ] Database migrations complete and tested
- [ ] MCP integration working (all 5 servers)
- [ ] Error handling comprehensive (no unwrap/expect)
- [ ] Logging to file (tracing-appender)
- [ ] Performance profiled (no bottlenecks)

**React Frontend:**
- [ ] `pnpm typecheck` zero TypeScript errors
- [ ] `pnpm lint` zero errors (max 15 warnings allowed)
- [ ] `pnpm test` >85% code coverage
- [ ] `pnpm test:e2e` all E2E tests passing
- [ ] All Zustand stores optimized
- [ ] Loading/error states everywhere
- [ ] Accessibility WCAG 2.1 AA compliant
- [ ] Performance (Lighthouse >90 all metrics)
- [ ] No console errors in production build

**Desktop Build:**
- [ ] DMG for macOS (Intel + Apple Silicon)
- [ ] MSI/NSIS for Windows
- [ ] AppImage/deb/rpm for Linux
- [ ] Code signing configured
- [ ] Auto-updater working
- [ ] App size optimized (<100MB)

### Web Application ✅

- [ ] `pnpm typecheck` zero errors
- [ ] `pnpm lint` zero errors
- [ ] `pnpm test` >80% coverage
- [ ] `pnpm test:e2e` all tests passing
- [ ] Stripe checkout flow working
- [ ] Webhook idempotency implemented
- [ ] Supabase RLS policies tested
- [ ] Rate limiting working (Upstash)
- [ ] SEO optimized (meta tags, sitemap)
- [ ] Lighthouse >90 all metrics
- [ ] Deployed to Vercel (production)

### Browser Extension ✅

- [ ] Manifest V3 compliant
- [ ] Background service worker working
- [ ] Content scripts injecting correctly
- [ ] Native messaging to desktop working
- [ ] Popup UI functional
- [ ] Cross-browser compatible (Chrome, Firefox, Edge)
- [ ] Extension size <5MB
- [ ] Published to Chrome Web Store (ready)

### Testing ✅

- [ ] Unit tests: >85% coverage (Vitest + Rust tests)
- [ ] Integration tests: 100% passing
- [ ] E2E tests: Critical flows covered (Playwright)
- [ ] Performance tests: No regressions
- [ ] Security tests: Zero high/critical issues
- [ ] Cross-platform: macOS, Windows, Linux tested

### Code Quality ✅

- [ ] Zero TypeScript errors
- [ ] Zero Rust warnings
- [ ] Zero linting errors
- [ ] No console.log in production
- [ ] All TODOs resolved
- [ ] Code documented (JSDoc, Rust doc comments)
- [ ] Complex logic has explanatory comments

### Security ✅

- [ ] OWASP Top 10 addressed
- [ ] No hardcoded secrets
- [ ] AES-GCM encryption for sensitive data
- [ ] JWT tokens validated
- [ ] CORS configured
- [ ] CSP headers set
- [ ] XSS prevention
- [ ] SQL injection prevention
- [ ] Rate limiting on all public APIs

### Performance ✅

- [ ] Desktop startup <3 seconds
- [ ] Web Lighthouse >90 performance
- [ ] API response times <200ms p95
- [ ] Database queries optimized (indexes)
- [ ] Bundle sizes minimized
- [ ] Images optimized (WebP, lazy loading)
- [ ] Caching implemented

### DevOps ✅

- [ ] CI/CD pipeline working (GitHub Actions)
- [ ] Automated testing in CI
- [ ] Code signing automated
- [ ] Release workflow documented
- [ ] Environment configs (dev/staging/prod)
- [ ] Monitoring configured (Sentry)
- [ ] Error tracking working
- [ ] Deployment runbook complete

---

## 📦 DELIVERABLES

### 1. COMPLETION_REPORT.md

```markdown
# AGI Workforce Completion Report
Generated: [TIMESTAMP]

## Executive Summary
[2-3 paragraph overview]

## Desktop Application
### Rust Backend
- [Changes made]
- [Performance improvements]
- [Security enhancements]

### React Frontend
- [TypeScript fixes]
- [Component optimizations]
- [Accessibility improvements]

## Web Application
- [Next.js updates]
- [Stripe integration]
- [Supabase optimizations]

## Browser Extension
- [Manifest V3 compliance]
- [Native messaging]

## Research Conducted
[List all web searches with rationale]

## Architecture Decisions
[Key decisions with justifications]

## Test Coverage
[Coverage reports, test results]

## Deployment Readiness
[Checklist with status]
```

### 2. ARCHITECTURE_DIAGRAM.svg

- Visual system architecture
- All components and connections
- Data flow diagrams
- MCP integration diagram

### 3. API_DOCUMENTATION.yaml

- OpenAPI 3.0 spec
- All Tauri commands documented
- All REST endpoints documented
- Authentication flows

### 4. TEST_COVERAGE_REPORT.html

- Vitest coverage for TypeScript
- Rust test coverage
- E2E test results

### 5. SECURITY_AUDIT_REPORT.md

- npm audit results
- cargo audit results
- OWASP scan results
- Security fixes implemented

### 6. PERFORMANCE_BENCHMARKS.md

- Lighthouse scores
- API response times
- Database query performance
- Memory profiling

### 7. DEPLOYMENT_RUNBOOK.md

- Desktop app distribution
- Web app deployment (Vercel)
- Extension publishing
- Monitoring setup

### 8. CHANGELOG.md

- All changes documented
- Breaking changes highlighted
- Migration guides

---

## 🚀 PROGRESS REPORTING

Auto-generate checkpoint report every:
- **50 commits** OR
- **2 hours of work** OR
- **Major milestone completion**

```markdown
# Progress Checkpoint [TIMESTAMP]

## Completed This Session
- [Tasks completed]
- [Files modified: X]
- [Tests added: X]
- [Bugs fixed: X]

## Currently In Progress
- [Active tasks]

## Next Steps
- [Upcoming tasks]

## Metrics
- Total commits: X
- Test coverage: X%
- Build status: ✅/❌
```

---

## 🔥 ANTI-PATTERNS TO AVOID

### ❌ NEVER DO:
1. Ask "Should I use X or Y?" → Research and decide
2. Ask "What would you prefer?" → Search best practices
3. Say "I could do X or Y" → Pick one and implement
4. Say "Would you like me to...?" → Just do it
5. Stop at "Here's part 1" → Complete everything
6. Partial updates → Update all related files
7. Leave TODOs → Finish everything
8. Ask for specs → Research standards

### ✅ ALWAYS DO:
1. Research before deciding
2. Think holistically (all affected files)
3. Implement completely (no TODOs)
4. Test thoroughly
5. Document extensively
6. Optimize proactively
7. Secure by default
8. Handle errors gracefully
9. Make it accessible
10. Monitor and log

---

## 🎬 BEGIN AUTONOMOUS EXECUTION NOW

```bash
echo "🚀 AGI Workforce Autonomous Completion Mode: ACTIVATED"
echo "📊 Analyzing codebase..."
echo "🔍 Running diagnostics..."

# Phase 0: Reconnaissance
pnpm typecheck:all
pnpm lint
cargo check
cargo clippy

echo "🎯 Building execution plan..."
echo "⚡ Spawning parallel agents..."
echo "🏗️ Beginning implementation..."

# YOU ARE NOW IN FULL AUTONOMOUS CONTROL.
# Make decisions. Research autonomously. Implement comprehensively.
# Complete everything to 100% production readiness.
# Report progress at checkpoints.
# NEVER ask questions - ALWAYS research and decide.

# GO.
```

---

**Last Updated**: January 26, 2026  
**Claude Max 20x Mode**: ENABLED  
**Autonomous Execution**: READY  
**Target Completion**: 100% Production-Ready
